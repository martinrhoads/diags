#!/usr/bin/env python

import getopt
import os
import string
import sys
import time
import traceback
import json

from cs_python_libs import HardwareEth
from cs_python_libs import Utils

debug=0
dryrun=0
logfile = "/root/bm-autoconf.log"
logfile_fp = None
default_file_content = """# bm-autoconf default config
run=NO
"""
substratum_bm_services = "ENABLED_SERVICES='api db dhcp dns tftp'"

ipv6_etc_hosts = """\n\n\n# The following lines are desirable for IPv6 capable hosts
::1     ip6-localhost ip6-loopback
fe00::0 ip6-localnet
ff00::0 ip6-mcastprefix
ff02::1 ip6-allnodes
ff02::2 ip6-allrouters
"""

def usage():
    cmd = os.path.basename(sys.argv[0])
    print "Usage: %s [-h|--help] [--host=gateway] [-n|--dryrun] [-d|--debug|--trace]" % cmd

def parse_default(data):
    default = {}
    for l in data.split("\n"):
        if not len(l.strip()):
            continue
        if l.strip().startswith("#"):
            continue
        try:
            k,v = l.split("=")
            default[k.strip()] = v.strip()
        except:
            continue
            
    return default
            
def main():
    global debug
    global dryrun
    global logfile
    global logfile_fp
    global substratum_bm_services
    global ipv6_etc_hosts
    
    pdu=False
    dryrun=0

    is_block_manager = False
    m_uuid = None
    hostname = None
    domain = None
    interfaces = None
    gateway_iface = None
    gateway_ip = None
    management_interface = None
    provision_interface = None
    traits = None

    gateway = None
    default_iface = "eth0"
    api_mac = None
    chef = False

    try:
        opts,args = getopt.getopt(sys.argv[1:], "hnd",["chef","help","debug","dryrun","trace","host=","logfile="])

        if debug:
            print >>sys.stderr, "parsing options"
        for o, v in opts:
            if o in ("-h", "--help"):
                usage()
                sys.exit(0)
            elif o in ("-d", "--debug", "--trace"):
                debug=1
            elif o in ("-n", "--dryrun"):
                dryrun=1
                debug=1
            elif o == "--dryrun":
                dryrun=True
            elif o == "--host":
                gateway = v
            elif o == "--chef":
                chef=True
            elif o=="--logfile":
                logfile = v
            else:
                print >>sys.stderr, "Not sure what to do with %s" % (o)
    except getopt.GetoptError,e:
        print >>sys.stderr, "missing options\n%s" % (e)
        # print help information and exit:
        usage()
        sys.exit(2)

    logfile_fp = open(logfile,'a')
    sys.stderr = logfile_fp
    sys.stdout = logfile_fp
    
    # Do we need to run.
    # if the file doesn't exist we need to check for 'is_block_manager' in the ZM
    if os.path.exists("/etc/default/bm-autoconf"):
        f = open("/etc/default/bm-autoconf")
        data = f.read()
        f.close()
        default = parse_default(data)
        if 'run' in default.keys():
            if default['run'] == 'NO':
                return 0

    # stop substratum and erase pid files
    cmds =[ ['stop','substratum-services'],
            ['rm', '-f', '/srv/substratum/services/tmp/*.pid'],
            ]

    for cmd in cmds:
        if debug :
            print >>sys.stderr, "Running %s\n" % cmd
        
        (s,o,e,f)=Utils.cmd_get_status_output(cmd, max_run_time = 300, get_stderr = True, timeout = 300)
        if s:
            print >>sys.stderr, "Error running %s\n" % cmd
            sys.stderr.flush()
        # give some times to the command to run
        time.sleep(5)

    #
    # Get mac addr of the iface on connected to the default gateway subnet so that we can talk to the ZM
    #
    if debug:
        print >>sys.stderr, "#\n# Use HardwareEth.getNetworkCards to get NIC and switchport info:\n#"
        sys.stderr.flush()
    if not gateway :
        gateway,default_iface = Utils.getDefaultGateway()
    if debug :
        print >>sys.stderr, gateway
        sys.stderr.flush()
        
    card_nb,eth_cards = HardwareEth.getNetworkCards(debug)

    for eth in eth_cards:
        if eth_cards[eth]['name'] == default_iface :
            api_mac = eth_cards[eth]['hw_add']

    # get some data from PSM
    if api_mac :
        if debug :
            print >>sys.stderr,  "Calling post_data('%s', 80, 'GET', '/machine/%s/all_attributes')." % (gateway,  api_mac)
            sys.stderr.flush()

        (status,reason,data) = Utils.xfer_data('%s' % gateway, 80, 'GET', '/machine/%s/all_attributes' % api_mac,"", debug)
        if status == 200 :
            decoder = json.JSONDecoder()
            d = decoder.decode(data)
            if type(d) is list:
                d = d[0]
            if type(d) is dict:

                if 'is_block_manager' in d.keys():
                    is_block_manager = d['is_block_manager']

                if 'id' in d.keys():
                    m_uuid = d['id']

                if 'hostname' in d.keys():
                    hostname = d['hostname']

                if 'domain' in d.keys():
                    domain = d['domain']

                if 'interfaces' in d.keys():
                    interfaces = d['interfaces']

                if 'gateway_iface' in d.keys():
                    gateway_iface = d['gateway_iface']

                if 'gateway_ip' in d.keys():
                    gateway_ip = d['gateway_ip']

                if 'management_interface' in d.keys():
                    management_interface = d['management_interface']

                if 'provision_interface' in d.keys():
                    provision_interface = d['provision_interface']

                if 'traits' in d.keys():
                    traits = d['traits']
            else:
                print >>sys.stderr,  "Error when connecting to the Zone manager on ip %s : %s" % (gateway, reason)
                sys.stderr.flush()
                return 1

    if debug :
        print >>sys.stderr, "is_block_manager : %s" % is_block_manager
        print >>sys.stderr, "hostname : %s" % hostname
        print >>sys.stderr, "domain : %s" % domain
        print >>sys.stderr, "interfaces : %s" % interfaces
        print >>sys.stderr, "gateway_iface : %s" % gateway_iface
        print >>sys.stderr, "gateway_ip : %s" % gateway_ip
        print >>sys.stderr, "management_interface : %s" % management_interface
        print >>sys.stderr, "provision_interface : %s" % provision_interface
        print >>sys.stderr, "traits : %s" % traits
        sys.stderr.flush()

    if is_block_manager:
        # update /etc/network/interfaces
        Utils.generate_iface(interfaces, gateway_iface, gateway_ip, domain, None, debug) 

        if not chef:
            # update /etc/hostname
            if debug :
                print >>sys.stderr, "Updating /etc/hostname"
                sys.stderr.flush()
            f = open("/etc/hostname", "w+")
            f.write(hostname)
            f.close()
            
            # update /etc/hosts
            if debug :
                print >>sys.stderr, "Updating /etc/hosts"
                sys.stderr.flush()
            f = open("/etc/hosts", "w+")
            if hostname and management_interface:
                f.write("127.0.0.1\tlocalhost\n")
                for iface in interfaces:
                    if iface['name'] == management_interface:
                        if domain :
                            f.write("%s\t%s.%s %s\n" % (iface['addresses'][0], hostname, domain, hostname))
                        else:
                            f.write("%s\t%s\n" % (iface['addresses'][0],  hostname))
                        break
            elif hostname and domain :
                f.write("127.0.0.1\tlocalhost\t%s.%s\n" % ( hostname, domain))
            else :
                f.write("127.0.0.1\tlocalhost\n")
            f.write(ipv6_etc_hosts)
            f.close()
            
            # update /etc/resolv.conf
            if debug :
                print >>sys.stderr, "Updating /etc/resolv.conf"
                sys.stderr.flush()
            f = open("/etc/resolv.conf", "w+")
            if domain:
                f.write("domain %s\n" % domain)
                f.write("search %s\n" % domain)
            f.write("nameserver %s\n" % gateway)
            f.write("nameserver 8.8.8.8\n")
            f.close()


        # rewrite /etc/substratum/config.json
        #   - API need to listen on both iface, other services only on the provision_interface
        service_address = None
        for iface in interfaces:
            if iface['name'] == provision_interface :
                service_address = iface['addresses'][0]
                break
        f = open("/etc/substratum/config.json","w")
        config={}
        config['default']={'address':service_address, 'log_level': 'info'}
        for service in  ['db','api']:
            config[service] = {}
            config[service]['address'] = '0.0.0.0'
            if service == 'api':
                config[service]['port']='80'
                    
        f.write(json.dumps(config))
        f.write("\n")
        f.close()
        
        # write /etc/default/bm-autoconf with run=NO in it.
        f = open ("/etc/default/bm-autoconf", 'w')
        f.write(default_file_content)
        f.close()

        # enable substratum BM service
        f = open("/etc/default/substratum",'a')
        f.write("\n%s\n" % substratum_bm_services)
        f.close()
        
        # are we running from Chef ?
        # if yes:
        #       - restart networing as we reconfigured the interfaces
        #       - start Block manager (we stoped it at the begining)
        # if not:
        #       - reboot the vm
        #
        if chef:
            cmds =[ ['stop','networking'],
                    ['start','networking'],
                    ['start','substratum-services'],
                ]

            for cmd in cmds:
                if debug :
                    print >>sys.stderr, "Running %s\n" % cmd
                
                (s,o,e,f)=Utils.cmd_get_status_output(cmd, max_run_time = 300, get_stderr = True, timeout = 300)
                if s:
                    print >>sys.stderr, "Error running %s\n" % cmd
                    sys.stderr.flush()
                # give some times to the command to run
                time.sleep(5)
        else:
            #update state in the Zone Manager
            post_data = {"state":"morphing_complete"}
            if m_uuid:
                (status,reason,data) = Utils.xfer_data('%s' % gateway, 80, 'PUT', '/machine/%s' % m_uuid, json.dumps(post_data), debug)
                if debug :
                    print >>sys.stderr, "(status,reason,data) = " , (status,reason,data)
                    sys.stderr.flush()

            if debug:
                print >>sys.stderr, "Rebooting\n"
            cmd = ['ipmitool', '-c', 'chassis', 'bootdev', 'pxe']
            (s,o,e,f)=Utils.cmd_get_status_output(cmd, max_run_time = 30, get_stderr = True, timeout = 30)
            cmd = ['ipmitool', '-c', 'chassis', 'power', 'cycle']
            (s,o,e,f)=Utils.cmd_get_status_output(cmd, max_run_time = 30, get_stderr = True, timeout = 30)
            cmd = ["/sbin/reboot"]
            (s,o,e,f)=Utils.cmd_get_status_output(cmd, max_run_time = 30, get_stderr = True, timeout = 30)

    return 0

if __name__=='__main__' :
    ret = main()
    logfile_fp.close()
    sys.exit(ret)

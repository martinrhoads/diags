# get network card info and cdp/lldp packet to locate where they are plugged
# need mii-tool and tshark/tshark

import os
import os.path
import re
import sys
import string
import traceback

# Sniffer command
max_run_time = 180
sniff_cmd = 'tshark -i %%s -V -l -a duration:%s -f "(ether host 01:00:0c:cc:cc:cc and ether[20:2] = 0x2000) or (ether host 01:80:c2:00:00:0e and ether proto 0x88cc)" -c 1 2>&1' % (max_run_time)

# Regex for result of mii-tool
nic_pat = re.compile(r'(eth\d+):\s+(.*)')
link_pat = re.compile(r'link ok')
# Regex for result of sniffer 
# Protocols in frame: CDP => Protocols in frame: eth:llc:cdp:data ; LLDP => Protocols in frame: eth:lldp
p_pat = re.compile(r'(Protocols in frame):\s(eth(?:\:\w+)+)',re.I)
# CDP packet regex
cdp_dev_pat = re.compile(r'^Device ID:\s(\S+)',re.I)
cdp_port_pat = re.compile(r'^Port ID:\s(\S+)',re.I)
cdp_vlan_pat = re.compile(r'^Native VLAN:\s(\S+)',re.I)
cdp_ip_pat = re.compile(r'^IP address:\s(\S+)',re.I)
# LLDP packet regex
lldp_dev_pat = re.compile(r'^System Name\s=\s(\S+)',re.I)
lldp_port_pat = re.compile(r'^Port Id:\s(\S+)',re.I)
lldp_vlan_pat = re.compile(r'^Port VLAN Identifier:\s(\S+)\s',re.I)
lldp_ip_pat = re.compile(r'^Management Address:\s(\S+)\s',re.I)
# Regex for result of ifconfig
mac_pat = re.compile(r'eth\d+.*HWaddr\s(\S+)',re.I)
    


# Get a CDP or LLDP packet to get the switch and port we're plugged in
def getCPD_LLDP(switch, name, p_debug = 0):

    if not os.path.exists("/usr/bin/tshark"):
        print >>sys.stderr, "/usr/bin/tshark is not installed."
        switch = {'device':'Error','port':'Error','vlan':'Error','dev_ip':'Error'}
        return

    ptype = None
    try:
        if p_debug:
            print >>sys.stderr, "run %s" % (sniff_cmd % name)
        fd=os.popen(sniff_cmd % name)
        cdp_packet=fd.read()
        fd.close()
        for pline in cdp_packet.split('\n'):
            pline = pline.strip()
            if p_debug==2:
                print >>sys.stderr,pline
            if not ptype and len(p_pat.findall(pline)) == 1:
                # LLDP packets
                if p_pat.findall(pline)[0][1] == 'eth:lldp':
                    ptype='lldp'
                    if p_debug:
                        print >>sys.stderr, "[%s] detected an lldp packet (%s)" % (name,ptype)
                # CDP packets
                elif p_pat.findall(pline)[0][1] == 'eth:llc:cdp:data':
                    ptype='cdp'
                    if p_debug:
                        print >>sys.stderr, "[%s] detected a cdp packet (%s)" % (name,ptype)
                else:
                    print >>sys.stderr, "Packet does not appear to be either LLDP or CDP."
                    sys.exit(1)
        
            #------------- CDP
            if ptype == 'cdp':
                dev = cdp_dev_pat.findall(pline)
                if len(dev) == 1:
                    switch['device'] = dev[0]
                    if p_debug:
                        print >>sys.stderr, "[%s] connected to %s." % (name,dev[0])
                port = cdp_port_pat.findall(pline)
                if len(port) == 1:
                    switch['port'] = port[0]
                    if p_debug:
                        print >>sys.stderr, "[%s] connected to port %s." % (name,port[0])
                vlan = cdp_vlan_pat.findall(pline)
                if len(vlan) == 1:
                    switch['vlan'] = vlan[0]
                    if p_debug:
                        print >>sys.stderr, "[%s] connected to port on vlan %s." % (name,vlan[0])
                ip = cdp_ip_pat.findall(pline)
                if len(ip) == 1:
                    switch['dev_ip'] = ip[0]
                    if p_debug:
                        print >>sys.stderr, "[%s] connected to switch with ip %s." % (name,ip[0])
            #------------- LLDP
            if ptype == 'lldp':
                dev = lldp_dev_pat.findall(pline)
                if len(dev) == 1:
                    switch['device'] = dev[0]
                    if p_debug:
                        print >>sys.stderr, "[%s] connected to %s." % (name,dev[0])
                port = lldp_port_pat.findall(pline)
                if len(port) == 1:
                    switch['port'] = port[0]
                    if p_debug:
                        print >>sys.stderr, "[%s] connected to port %s." % (name,port[0])
                vlan = lldp_vlan_pat.findall(pline)
                if len(vlan) == 1:
                    switch['vlan'] = vlan[0]
                    if p_debug:
                        print >>sys.stderr, "[%s] connected to port on vlan %s." % (name,vlan[0])
                ip = lldp_ip_pat.findall(pline)
                if len(ip) == 1:
                    switch['dev_ip'] = ip[0]
                    if p_debug:
                        print >>sys.stderr, "[%s] connected to switch with ip %s." % (name,ip[0])
    except Exception,e:
        if p_debug :
            tb="".join(traceback.format_exception(sys.exc_info()[0],sys.exc_info()[1],sys.exc_info()[2]))
            print >>sys.stderr, "%s:\n%s" % (e,tb)
        switch = {'device':'Error','port':'Error','vlan':'Error','dev_ip':'Error'}
        pass

def getNetworkCards(p_debug = 0):
    card_nb=0
    eth_cards=dict()
    
    if os.geteuid () != 0:
        if p_debug:
            print >>sys.stderr, "can't test for network cards and connections unless you are root"
        return card_nb,eth_cards

    if not os.path.exists("/sbin/ethtool"):
        # ethtool is missing
        print >>sys.stderr, "ethtool is not installed."
        return 0, None

    if not os.path.exists("/sbin/ifconfig"):
        # ethtool is missing
        print >>sys.stderr, "ifconfig is not installed."
        return 0, None

    try:
        # Get ethernet interface(s)
        i=0
        eth=[]
        while True:
            cmd = "/sbin/ethtool eth%d 2>/dev/null" % i
            fd=os.popen(cmd)
            eth_state=fd.read()
            fd.close()
            if eth_state.find("No data available") == -1:
                eth.append("eth%d" %i)
            else :
                break
            i += 1

        for name in eth:

            if p_debug:
                print >>sys.stderr, name

            # get mac
            ifcg_cmd = '/sbin/ifconfig %s' % (name)
            if p_debug:
                print >>sys.stderr, "run %s" % (ifcg_cmd)
            fd=os.popen(ifcg_cmd)
            eth_conf=fd.read()
            fd.close()
            hw_add=''
            for conf_line in eth_conf.split("\n") :
                if p_debug==2:
                    print >>sys.stderr, conf_line
                if len(mac_pat.findall(conf_line)) == 1:
                    hw_add = mac_pat.findall(conf_line)[0]
                    if p_debug:
                        print >>sys.stderr, "[%s] has mac address of %s" % (name,hw_add)
                    break

            eth_cards[card_nb] = {}
            eth_cards[card_nb]['name'] = name
            eth_cards[card_nb]['hw_add'] = hw_add
            card_nb+=1
        # End main for loop
    except Exception,e:
        if p_debug :
            tb="".join(traceback.format_exception(sys.exc_info()[0],sys.exc_info()[1],sys.exc_info()[2]))
            print >>sys.stderr, "%s:\n%s" % (e,tb)
        eth_cards[card_nb]={'name':'Error','hw_add':'Error'}
        pass

    return card_nb,eth_cards
#

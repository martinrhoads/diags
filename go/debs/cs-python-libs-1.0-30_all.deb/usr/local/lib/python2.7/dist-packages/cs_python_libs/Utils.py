import os
import os.path
import sys
import fcntl
import time
import threading
import logging
import select
import string
import traceback
import base64
import httplib
import mimetypes

from urllib import urlencode


def debug_print(msg=None,p_debug=0):
    """
    Print msg to stderr if debug  > 0
    """

    if msg != None and p_debug > 0:
        print >>sys.stderr, msg


def makeNonBlocking(fd):
    fl=fcntl.fcntl(fd,fcntl.F_GETFL)
    try:
        fcntl.fcntl(fd,fcntl.F_SETFL,fl| os.O_NDELAY)
    except AttributeError:
        fcntl.fcntl(fd,fcntl.F_SETFL,fl| os.FNDELAY)

#
# Function : cmd_get_status_output(cmd, max_run_time=None, get_stderr=False, timeout=30, p_debug=False)
#
# Author : Rodolphe Pineau
# Descr : exec a command and get the output
# Params:
#   - cmd : either a string containing the command
#           or a sequence
#   - max_run_time : maximum time the command should run in seconds (None by default)
#   - get_stderr :  do we want the sdterr from the command (True/False)
#   - timeout : timeout in seconds (30 by default)
#   - p_debug : do we want debugging (True/False)
#
# return values :
# status : the command exit status 
# output : output of the command
# error  : stderr from the command
# fn_status : exit code of the function. -1 : exited after timeout, -2 : exited after max_run_time
#
# Sample code:
#   (s,o,e,f)=cmd_get_status_output("/bin/ls /tmp",get_stderr=True,timeout=10,p_debug=True)
#   cmd="ssh -A rpineau@host.foo.com /bin/ls" # => will spawn a shell
#   cmd=['ssh','-A','rpineau@host.foo.com','/bin/ls'] # -> will do a proper execv
#
def cmd_get_status_output(cmd, max_run_time=None, get_stderr=False, timeout=30, p_debug=False):
    """
    Run a command with the given timeout.  Return the output.errors and the exit
    status from the command as well as a exit statrus of the function itself.
    An exit status of -1 indicates that the function timed out and  process had to be killed.
    """
        
    p_output=""
    p_error=""
    p_status=None
    p_timeout=0
    idle=1
    fn_result=0
    p_max_run_time=0

    if p_debug:
        print >>sys.stderr, "cmd: ",cmd
        print >>sys.stderr, "max_run_time: ",max_run_time
        print >>sys.stderr, "get_stderr: ",get_stderr
        print >>sys.stderr, "timeout: ",timeout
        print >>sys.stderr, "p_debug: ",p_debug

    try:
        MAXFD = os.sysconf('SC_OPEN_MAX')
    except (AttributeError, ValueError):
        MAXFD = 256
    
    bufsize=-1
    # now prepare the pipes
    p2cread, p2cwrite = os.pipe()
    c2pread, c2pwrite = os.pipe()
    
    if get_stderr:
        errout, errin = os.pipe()

    # fork the  child
    pid = os.fork()
    if pid == 0:
        # Child
        os.dup2(p2cread, 0)
        os.dup2(c2pwrite, 1)
        if get_stderr:
            os.dup2(errin, 2)
        if isinstance(cmd, basestring):
            cmd = ['/bin/sh', '-c', cmd]
        for i in range(3, MAXFD):
            try:
                os.close(i)
            except OSError:
                pass
        try:
            os.execvp(cmd[0], cmd)
        finally:
            os._exit(1)

    # parent
    os.close(p2cread)
    tochild = os.fdopen(p2cwrite, 'w', bufsize)
    os.close(c2pwrite)
    fromchild = os.fdopen(c2pread, 'r', bufsize)
    if get_stderr:
        os.close(errin)
        childerr = os.fdopen(errout, 'r', bufsize)
    else:
        childerr = None
    
    # make fd non blocking
    outfd=fromchild.fileno()
    makeNonBlocking(outfd)
    if get_stderr:
        errfd=childerr.fileno()
        makeNonBlocking(errfd)

    # put the subprocess in its own process group, so that we can
    # send it and all of its children the same signal
    try:
      os.setpgid (pid, pid)
    except:
      # this can happen because the command finishes before we
      # are able to set the process group
      debug_print("could not set pgrp of pid %s -- ignoring" % (pid),p_debug)
    
    while True:
        try:
            (p,s) = os.waitpid(pid, os.WNOHANG)
            if pid == p:
                p_status = s
                break
            # try to read some output
            if get_stderr:
                ready=select.select([outfd,errfd],[],[],.1)
            else:
                ready=select.select([outfd],[],[],.1)
            
            if outfd in ready[0]:
                outchunk=fromchild.read()
                debug_print("got some stdout from child : %s" % (outchunk),p_debug)
                p_output+=outchunk
                p_timeout=0

            if get_stderr:
                if errfd in ready[0]:
                    errchunk=childerr.read()
                    debug_print("got some sterr from child : %s" % (errchunk),p_debug)
                    p_error+=errchunk
                    p_timeout=0
                    
            select.select([],[],[],.1) # allow some time for buffers to fiil
            
            time.sleep(idle)

            # check for timeout and run time
            p_timeout+=idle
            if(p_timeout>=timeout):
                debug_print("killing process pid %s" % (pid),p_debug)
                try:
                    os.killpg(pid,SIGTERM)
                except:
                    debug_print("kill pid %s with SIGTERM failed, ignoring" % (pid),p_debug)
                    pass
                fn_result=-1
                break

            if max_run_time:
                p_max_run_time+=idle
                if(p_max_run_time>=max_run_time):
                    debug_print("killing process pid %s" % (pid),p_debug)
                    try:
                        os.killpg(pid,SIGTERM)
                    except:
                        debug_print("kill pid %s with SIGTERM failed, ignoring" % (pid),p_debug)
                        pass
                    fn_result=-2
                    break
                     
        except os.error:
            pass

    # waitpid returns the same thing as the C library -- that is, exit
    # status plus a bunch of flags.  We need to call the WEXITSTATUS
    # function to get the actual process exit status.
    if p_status:
        p_status = os.WEXITSTATUS(p_status)

    debug_print("p_status = %s" % (p_status),p_debug)

    # do a waitpid to be sure the process doesn't stay around as a zombie
    if not p_status:
        # if p_status is less than zero, the last poll didn't have any status
        # information for us, therefore we had to kill the process
        try:
            (p,s)=os.waitpid(pid,os.WNOHANG)
            debug_print("waitpid pid %s returned p %s s %s" % (pid,p,s),p_debug)
        except:
            debug_print("waitpid pid %s failed" % (pid),p_debug)
            pass
        try:
            os.killpg(pid,SIGKILL)
        except:
            debug_print("kill pid %s with SIGKILL failed, ignoring" % (pid),p_debug)
            pass                  

    # try a last read to be sure we have the whole output and errors
    try:
        outchunk=fromchild.read()
        p_output+=outchunk
        if get_stderr:
            errchunk=childerr.read()
            p_error+=errchunk
    except:
        pass

    # close out fd
    try:
        fromchild.close()
        if get_stderr:
            childerr.close()
        tochild.close()
    except:
        pass

    return p_status,p_output,p_error,fn_result


def xfer_data(host, port, method, selector, data, debug = False):
    body=data
    content_type="text/json"
    
    if debug : 
        print >>sys.stderr, "%sing data using http://%s:%s%s" % (method,host,port,selector)
        sys.stderr.flush()
        
    h = httplib.HTTPConnection(host,port)  
    headers = {
        'User-Agent': 'Mini-Boot',
        'Content-Type': content_type
        }

    try:
        h.request(method, selector, body, headers)
        res = h.getresponse()
    except Exception, e:
        if debug :
            tb="".join(traceback.format_exception(sys.exc_info()[0],sys.exc_info()[1],sys.exc_info()[2]))
            print >>sys.stderr,"Error durring HTTP connection : ",e,tb 
            sys.stderr.flush()
        return -1,'connection refused',''
    return res.status, res.reason, res.read() 

def getOS():
    fd = open('/etc/issue')
    data = fd.read()
    fd.close()
    data = data.lower().strip().split()
    return {'os': data[0], 'os_version': data[1]}
    
def getDefaultGateway():
    default_gateway = None
    default_if = None

    if sys.platform == "darwin":
        if not os.path.exists("/bin/netstat"):
            print >>sys.stderr, "/bin/netstat is not installed."
            return default_gateway,default_if
        fd = os.popen('/bin/netstat -nr')
        routing_table = fd.read()
        fd.close()
        for line in routing_table.split("\n"):
            if line.find("default") != -1:
                if line.index("default") == 0 :
                    entry = line.split()
                    if len(entry)<5:
                        # IPv6
                        default_gateway = entry[1]
                        default_if = entry[3]
                    else:
                        #IPv4
                        default_gateway = entry[1]
                        default_if = entry[5]
                    break
    else :
        if not os.path.exists("/sbin/route"):
            print >>sys.stderr, "/sbin/route is not installed."
            return default_gateway,default_if
        fd = os.popen('/sbin/route -n')
        routing_table = fd.read()
        fd.close()
        for line in routing_table.split("\n"):
            if line.find("0.0.0.0") != -1:
                if line.index("0.0.0.0") == 0 :
                    entry = line.split()
                    default_gateway = entry[1]
                    default_if = entry[7]
                    break
    return default_gateway,default_if

def sort_iface_by_mac(ifaces, debug = False):
    new_ifaces = []
    # build a new dictionary sorted on mac addresses only for eth0 adn eth1
    # in mac ascending order
    # we sort eth0 and eth1 only if they are from the same manufacturer.
    # if we sort them with different manufacturer we risk swapping them
    # example from our dev machines :
    # eth0 : E0:69:95:78:03:93
    # eth1 : 00:1B:21:AD:91:88
    #
    new_ethx={}
    for iface in ifaces:
        if iface['name'] == 'eth0' or iface['name'] == 'eth1' :
            new_ethx[iface['mac']] = dict(iface.items())

    if len(new_ethx):
        mac_keys = new_ethx.keys()
        # compare the 3 first byte of the macs, if they match, sort the macs:
        if mac_keys[0][0:9] == mac_keys[1][0:9]:
            mac_keys.sort()
            i = 0
            for iface_mac in mac_keys:
                name = "eth%d" % i
                i += 1
                (('name', name), ('mac', iface_mac))
                del new_ethx[iface_mac]['mac'] # we don't need the mac address as it's the key
                tmp = dict(new_ethx[iface_mac].items() + [('name', name), ('mac', iface_mac)])
                new_ifaces.append(tmp)
        else : # if not, don't touch anything
            for iface in new_ethx:
                new_ifaces.append(new_ethx[iface])
    next_iface_start = len(new_ifaces)
    # do the same for all other interfaces
    # build a new dictionary sorted on mac addresses
    # in mac ascending order 
    new_ethx={}
    for iface in ifaces:
        if iface['name'] != 'eth0' and iface['name'] != 'eth1' :
            new_ethx[iface['mac']] = dict(iface.items())
            del new_ethx[iface['mac']]['mac']  # we don't need the mac address as it's the key.

    if len(new_ethx):
        mac_keys = new_ethx.keys()
        mac_keys.sort()
        i = next_iface_start
        for iface_mac in mac_keys:
            name = "eth%d" % i
            i += 1
            (('name', name), ('mac', iface_mac))
            tmp = dict(new_ethx[iface_mac].items() + [('name', name), ('mac', iface_mac)])
            new_ifaces.append(tmp)

    return new_ifaces

def generate_iface(interfaces, gateway_iface, gateway_ip, domain, prefix=None, debug=False):
    interfaces_file="# Generated by bm-autoconf.py\nauto lo\niface lo inet loopback\n"
    for iface in interfaces:
        aliases=None
        need_dns = False
        iface_name = iface['name']
        iface_plumbing = iface['plumbing']
        if debug :
            print >>sys.stderr, "iface : %s\n" % iface_name
            print >>sys.stderr, "\tiface_plumbing %s:\n" % iface_plumbing
        entry="auto %s\niface %s inet %s\n" % (iface_name, iface_name, iface_plumbing)
        for k in iface.keys():
            if k in ["name", "plumbing", "type", "mac", "gateway"]:
                if debug :
                    print >>sys.stderr, "\tnot using %s %s:\n" % (k,iface[k])
                continue
            elif k == "addresses":
                if debug :
                    print >>sys.stderr, "\t%s %s:\n" % (k,iface[k])
                if not aliases and len(iface[k]):
                    entry += "\taddress %s\n" % iface[k][0]
                if len(iface[k])>1:
                    # we need to create interface aliases
                    aliases = []
                    for a in iface[k][1:]:
                       aliases.append(a)
            elif iface[k]:
                if debug :
                    print >>sys.stderr, "\t%s %s:\n" % (k,iface[k])
                entry += "\t%s %s\n" % (k, iface[k])

        if gateway_iface == iface_name:
                if debug :
                    print >>sys.stderr, "\tgateway %s\n" % gateway_ip
                if gateway_ip :
                    entry += "\tgateway %s\n" % gateway_ip
                    need_dns = True
                else :
                    print >>sys.stderr, "\t[WARNING] gateway_ip is not set %s\n" % gateway_ip

        if need_dns:
            if debug :
                print >>sys.stderr, "adding dns entries"
            # fix for ubuntu 12.04 and up
            if domain :
                entry += "\tdns-search %s\n" % domain
                entry += "\tdns-domain %s\n" % domain
            entry += "\tdns-nameservers %s 8.8.8.8\n" % gateway_ip
        
        entry+="\n"
        interfaces_file += entry
        if aliases :
            n = 0 #iface alias number
            for a in aliases :
                entry="auto %s:%s\niface %s:%s inet %s\n" % (iface_name, n, iface_name, n, iface_plumbing)
                for k in iface.keys():
                    if k in ["name", "plumbing", "type", "mac", "gateway"]: # no gateway on aliases
                        continue
                    elif k == "addresses":
                        entry += "\taddress %s\n" % a
                    elif iface[k]:
                        entry += "\t%s %s\n" % (k, iface[k])
                entry+="\n"
                interfaces_file += entry
                n+=1

    if debug :
        print >>sys.stderr, "Interfaces = \n", interfaces_file
        sys.stderr.flush()
    if prefix :
        f_name = "%s/etc/network/interfaces" % prefix
    else :
        f_name = "/etc/network/interfaces"
        
    f=open(f_name,"w+")
    f.write(interfaces_file)
    f.close()
        
        
        
class task_thread (threading.Thread):
    def __init__(self, cmd, run_time):
        threading.Thread.__init__(self)
        self.cmd = cmd
        self.run_time = run_time
        self.thread_name="task_thread"
        self.cmd_status = 0
        self.errors = []

    def run(self):
        logging.debug( "starting %s" % self.thread_name)
        start = time.time()
        end = start + self.run_time
        while time.time() < end:
            (s,o,e,f)=cmd_get_status_output(self.cmd, max_run_time = self.run_time, get_stderr = True, timeout = self.run_time)
            # store the status over multiple runs
            if s:
                self.cmd_status |= s
            elif s is None:
                if f != -2 :    # -2 = timetout , command took to long to run, which in our case is fine
                    self.cmd_status = 1 # there was some sort of error and s returned as None
                    s = 1
            # store the output when there is an error
            if s:
                self.errors.append(o+e)

class simple_thread (threading.Thread):
    def __init__(self, cmd, run_time):
        threading.Thread.__init__(self)
        self.cmd = cmd
        self.run_time = run_time
        self.thread_name="simple_thread"
        self.cmd_status = 0
        self.errors = []
        
    def run(self):
        logging.debug( "starting %s" % self.thread_name)
        (s,o,e,f)=cmd_get_status_output(self.cmd, max_run_time = self.run_time, get_stderr = True, timeout = self.run_time)
        # store the status 
        if s:
            self.cmd_status = s
        elif s is None:
            if f != -2 :    # -2 = timetout , command took to long to run, which in our case is fine
                self.cmd_status = 1 # there was some sort of error and s returned as None
                s = 1
        # store the output when there is an error
        if s:
            self.errors.append(o+e)

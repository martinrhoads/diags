# This lib defines functions interract with the LSI MegaRAID controler
import os
import os.path
import sys
import string
import traceback
import subprocess
import shlex

import Utils


class Controller(object):

    def __init__(self, controller_num, debug = False):
        self.debug = debug
        self.megacli = None
        self.controller = None
        self.disks = []
        self.adapter_present = None
        
        # get system arch to set the cli to the right one
        (s,o,e,f)=Utils.cmd_get_status_output(["/usr/bin/arch"], p_debug = self.debug)
        arch = o.strip()
        if arch == "x86_64":
            self.megacli = "/opt/MegaRAID/MegaCli/MegaCli64"
        elif arch == "i386" or arch == "i686":
            self.megacli = "/opt/MegaRAID/MegaCli/MegaCli"
        else :
            print "Unsuported CPU architecture for the MegaCli tool (or /usr/bin/arch is not installed)."
            return

        if not os.path.exists(self.megacli):
            if self.debug:
                print "%s not installed." % self.megacli
            return
            
        # check to see if there is an adapter on the box
        if not self.check_adapter():
            self.adapter_present = False
            return

        self.adapter_present = True
        
        if controller_num is not None:  # a0, a1, ..., aN
            self.controller = controller_num
            
            self.get_disks()

    def check_adapter(self) :
        nb_controller = None
        # this stupid command returns the number of adapter, so the exit code is non 0 even if it succeed
        cmd = [self.megacli, "-adpCount"]
        (s,o,e,f)=Utils.cmd_get_status_output(cmd, get_stderr= True, timeout = 90, p_debug = self.debug)

        for line in o.split("\n"):
            if line.find("Controller Count:") != -1:
                nb_controller = int(line.split(":")[1].strip().strip("."))
                break
                
        return nb_controller       

    def clear_config(self):
        if self.controller is None:
            return -1
        status = 0
        
        cmds = [[self.megacli, "-CfgForeign", "-Clear", "-a%s" % self.controller],
                [self.megacli, "-CfgClr", "-Force", "-a%s" % self.controller]
                ]
        for cmd in cmds:
            (s,o,e,f)=Utils.cmd_get_status_output(cmd, get_stderr= True, timeout = 90, p_debug = self.debug)
            status |= s
        if s :
            print "error clearing config on controller %s : %s" % (self.controller, o+e)
        return s        

    def get_disks(self):
        if self.controller is None:
            return

        # parse the enclosure
        cmd = [self.megacli, "-EncInfo", "-a%s" % self.controller]
        (s,o,e,f)=Utils.cmd_get_status_output(cmd, get_stderr= True, timeout = 90, p_debug = self.debug)
        if s :
            print "error getting enclosure info on controller %s : %s" % (self.controller, o+e)
            return

        nb_enclosure = 0
        for line in o.split("\n"):
            if line.find("Number of enclosures on adapter %s" % self.controller) != -1:
                # check for the number of enclosure
                nb_enclosure = int(line.split("--")[1].strip())

        # check the enclosure for their ID
        enclosure_found = -1
        enclosure_number = 0
        enclosure_ids = []
        for line in o.split("\n"):
            if line.find("    Enclosure") != 1 :
                if line == "    Enclosure %s:" % enclosure_number:
                    enclosure_found = enclosure_number
            
            if line.find("Device ID") != -1 and enclosure_found == enclosure_number :
                enclosure_id = line.split(":")[1].strip()

            if line.find("Number of Physical Drives") != -1 and enclosure_found == enclosure_number :
                nb_drives = line.split(":")[1].strip()
                enclosure_ids.insert(enclosure_number,(enclosure_id,nb_drives))
                enclosure_number += 1

        for enclosure_id,nb_drives in enclosure_ids :
            for drive in xrange(0,int(nb_drives)):
                line = "%s:%s" % (enclosure_id, drive)
                self.disks.append(line)
    
    def setCache(self, mode):
        """ set the array cache mode
        'WT' : write-trough
        'WB' : write-back
        """
        if self.controller is None:
            return
        status = 0
        # -LDSetProp WT -LALL -aALL
        cmd = [self.megacli, "-LDSetProp", mode, "-Lall", "-a%s" % self.controller]
        (s,o,e,f)=Utils.cmd_get_status_output(cmd, get_stderr= True, timeout = 90, p_debug = self.debug)
        if s:
            print "error setting cache to write-trough on controller %s : %s " % (self.controller, o+e)

        status |= s
        if mode=="WB" and o.find("WB will not come into effect immediately") != -1 :
            # we need to force the bad BBU behavior to let us use WB
            # -LDSetProp -CachedBadBBU  -Lall -a0
            cmd = [self.megacli, "-LDSetProp", "-CachedBadBBU", "-Lall", "-a%s" % self.controller]
            (s,o,e,f)=Utils.cmd_get_status_output(cmd, get_stderr= True, timeout = 90, p_debug = self.debug)
            if s:
                print "error setting BBU cache mode on controller %s : %s " % (self.controller, o+e)
    
            status |= s
            
        return status
        
    def make_test_raid0(self):
        """ Set all disk as raid 0 as JBOD is not working for now"""
        if self.controller is None:
            return
        
        self.clear_config()
        self.onlineAllDisks()

        status = 0
        for disk in self.disks:
            cmd = [self.megacli, "-CfgLdAdd", "-r0", "[%s]" % disk, "-a%s" % self.controller] 
            (s,o,e,f)=Utils.cmd_get_status_output(cmd, get_stderr= True, timeout = 90, p_debug = self.debug)
            if s :
                print "error setting raid 0 on controller %s disk %s : %s" % (self.controller, disk,  o+e)
            status |= s

        # set cache to Write-Trough
        s = self.setCache('WT')
        status |= s

        return status

    def make_raid6(self, nb_spares = 0):
        if self.controller is None:
            return
        
        self.clear_config()
        self.onlineAllDisks()
        
        status = 0
        # raid 6
        if not nb_spares :
            disks = ",".join(self.disks)
        else:
            disks = ",".join(self.disks[:-nb_spares])
        
        cmd = [self.megacli, "-CfgLdAdd", "-r6", "[%s]" % disks, "-a%s" % self.controller]
        (s,o,e,f)=Utils.cmd_get_status_output(cmd, get_stderr= True, timeout = 90, p_debug = self.debug)
        if s:
            print "error creating RAID 6 on controller %s : %s " % (self.controller, o+e)
            return s
        status |= s

        if nb_spares:
            # add spares
            for i in xrange(0,nb_spares):
                cmd = [self.megacli, "-PDHSP", "-Set", "-PhysDrv", "[%s]" % self.disks[-nb_spares+i], "-a%s" % self.controller]
                (s,o,e,f)=Utils.cmd_get_status_output(cmd, get_stderr= True, timeout = 90, p_debug = self.debug)
                if s:
                    print "error adding spare drive %s on controller %s : %s " % (self.disks[-nb_spares+i],self.controller, o+e)
                status |= s

        # set cache to Write-Trough
        s = self.setCache('WT')
        status |= s

        return status


    def rescan_bus(self):
        adapters = os.listdir("/sys/class/scsi_host/")
        for adapter in adapters:
            f = open("/sys/class/scsi_host/%s/scan" % adapter,'w')
            f.write("- - -")
            f.close()

    def get_disks_status(self):
        if self.controller is None:
            return

        disks_status = {}
        status = 0
        for disk in self.disks:
            cmd = [self.megacli, "-pdInfo", "-PhysDrv", "[%s]" % disk, "-a%s" % self.controller] 
            (s,o,e,f)=Utils.cmd_get_status_output(cmd, get_stderr= True, timeout = 90, p_debug = self.debug)
            if s :
                print "error getting status of drive %s on controler %s: %s" % (disk, self.controller,  o+e)
            status |= s
            if not s:
                for line in o.split("\n"):
                    if line.find("Firmware state") != -1 :
                        d_status = line.split(":")[1].strip()
                        if d_status.lower().find("bad)") != -1:
                            disks_status[disk] = "bad"
                        else:
                            disks_status[disk] = "ok"
                        break
                        
        return status,disks_status

    def onlineAllDisks(self):
        """Set all the disk as good and online. If some are bad they will be re-detected as bad latter by the array"""
        
        for disk in self.disks:
            cmds = [[self.megacli, "-PDMakeGood", "-PhysDrv", "[%s]" % disk, "-a%s" % self.controller], 
                    [self.megacli, "-PDOnline", "-PhysDrv", "[%s]" % disk, "-a%s" % self.controller]]
            for cmd in cmds:
                (s,o,e,f)=Utils.cmd_get_status_output(cmd, get_stderr= True, timeout = 90, p_debug = self.debug)

# This lib defines functions to retreives hardware
# data from machines

import os
import sys
import string
import traceback
import subprocess
import shlex


def loadFiberModules(p_debug=0):
    if p_debug:
        print "Trying to load HBA kernel modules"
    if os.geteuid () != 0:
        if p_debug: print >>sys.stderr, "can't load fiber cards module unless you are root"
        return False
    
    # load the module for the fibre cards
    if not os.path.isfile("/bin/busybox"):
        if p_debug : print >>sys.stderr, "loading module scsi_transport_fc"
        os.system("/sbin/modprobe scsi_transport_fc >/dev/null 2>&1")
        if p_debug : print >>sys.stderr, "loading module qla2xxx"
        os.system("/sbin/modprobe qla2xxx >/dev/null 2>&1")
        if p_debug : print >>sys.stderr, "loading module qla4xxx"
        os.system("/sbin/modprobe qla4xxx >/dev/null 2>&1")
        if p_debug : print >>sys.stderr, "loading module qla2300"
        os.system("/sbin/modprobe qla2300 >/dev/null 2>&1")
    else:
        if p_debug : print >>sys.stderr, "loading module scsi_transport_fc"
        os.system("/sbin/insmod scsi_transport_fc >/dev/null 2>&1")
        if p_debug : print >>sys.stderr, "loading module qla2xxx"
        os.system("/sbin/insmod qla2xxx >/dev/null 2>&1")
        if p_debug : print >>sys.stderr, "loading module qla4xxx"
        os.system("/sbin/insmod qla4xxx >/dev/null 2>&1")
        if p_debug : print >>sys.stderr, "loading module qla2300"
        os.system("/sbin/insmod qla2300 >/dev/null 2>&1")
    return True
    

def unloadFiberModules(p_debug=0):
    if p_debug:
        print >>sys.stderr, "Trying to unload HBA kernel modules"
    if os.geteuid () != 0:
        if p_debug: print >>sys.stderr, "can't unload fiber cards module unless you are root"
        return False
    # unload the module
    os.system("/sbin/rmmod qla2300 >/dev/null 2>&1")
    os.system("/sbin/rmmod qla2xxx >/dev/null 2>&1")
    os.system("/sbin/rmmod qla4xxx >/dev/null 2>&1")
    os.system("/sbin/rmmod scsi_transport_fc >/dev/null 2>&1")
    return True
    

def get_fibre_cards(LoadUnload=False,p_debug=0):
    cards=[]

    if LoadUnload:
        if not loadFiberModules(p_debug=p_debug):
            return None

    # get the number of adapter :
    if p_debug:
        print >>sys.stderr, "Run: /sbin/lspci and look for fibre channel cards."
    fd=os.popen("/sbin/lspci | grep Fibre")
    pci_cards=fd.read()
    fd.close()
    if len(pci_cards):
        pci_cards=pci_cards.strip().split("\n")
        card_count = len(pci_cards)
        if p_debug:
            print >>sys.stderr, "Found %s Fibre cards." % (card_count)
        for card in pci_cards:
            id=eval(card.split()[0].split('.')[1])
            cards.insert(id,{'pci':" ".join(card.split()[3:]), 'WWN':''})
            if p_debug:
                print >>sys.stderr, "  %s: %s" % (id,cards[id])

        # RedHat 3.x/4.x
        wwn_found=0
        if p_debug:
            print >>sys.stderr, "Looking for WWNs:"
            print >>sys.stderr, " - In /proc/scsi"
        wwn_base_path = None
        ls = os.listdir("/proc/scsi")
        if "qla2xxx" in ls:
            wwn_base_path = "/proc/scsi/qla2xxx"
        elif "qla2300" in ls:
            wwn_base_path = "/proc/scsi/qla2300"
        if wwn_base_path:
            # Look for files in wwn_base_path and extract WWNs
            ls = os.listdir(wwn_base_path)
            for x in ls:
                wwn_path="%s/%s" % (wwn_base_path,x)
                if p_debug:
                    print >>sys.stderr, "  %s in %s" % (x,wwn_path)

                #--
                if os.path.isfile(wwn_path):
                    fd=os.popen("cat %s" %wwn_path)          
                    infos=fd.read()
                    fd.close()
            
                    for line in infos.split('\n'):
                        if line.find('scsi-qla%s-adapter-port' % x)!=-1:
                            wwn=line.split('=')[1].strip(';')
                            if p_debug:
                                print >>sys.stderr, "  Found: %s" % (wwn)
                            if len(wwn):
                                wwn_found+=1
                                cards[int(x)]['WWN']=wwn
        else:
            if p_debug:
                print >>sys.stderr, "No base path defined .. skipping El3/EL4 style discovery."

        # CentOS 5/5.3
        if wwn_found != len(cards):
            if p_debug:
                print >>sys.stderr, " - In /sys/class/fc_host"
            wwn_found=0
            wwn_base_path="/sys/class/fc_host"
            wwn_path = None
            if os.path.isdir(wwn_base_path):
                ls = os.listdir(wwn_base_path)
                x = 0
                for hostx in ls:
                    wwn_path="/sys/class/fc_host/%s/port_name" % hostx
                    if os.path.isfile(wwn_path):
                        if p_debug:
                            print >>sys.stderr, "  %s in %s" % (x,wwn_path)

                        fd=open(wwn_path)
                        infos=fd.read()
                        fd.close()
                        wwn=infos.split('x')[1].strip()
                        if p_debug:
                            print >>sys.stderr, "  Found: %s" % (wwn)
                        if len(wwn):
                            wwn_found+=1
                            cards[x]['WWN']=wwn
                    # iterate the counter
                    x += 1
    else:
        if p_debug:
            print >>sys.stderr, "No fibre cards were found using lspci.."
        
    if LoadUnload:
        unloadFiberModules(p_debug=p_debug)
    
    return cards

def getMemoryInfo(p_debug=0):
    
    mem={}
    cmd="/usr/sbin/dmidecode"
    if os.geteuid() != 0:
        cmd = 'sudo ' + cmd
    try:
        fd=os.popen(cmd)
        data=fd.read()
    except:
        return mem
            
    try:
        fd.close()
    except:
        pass
        
    dmi_data=data.split("Handle 0x")
    
    
    for handle in dmi_data:
        if handle.find("DMI type 17")!=-1:
            if p_debug : print >>sys.stderr, "find DMI entry for memory"
            mem_tmp={}
            mem_key=None
            speed=None
            size=None
            
            for field in handle.replace("\t","").split("\n"):
                k_v=field.split(":")
                if len(k_v)>1:
                    if p_debug : print k_v
                    k,v=(k_v[0].strip(),k_v[1].strip())
    
                    if k=="Size":
                        mem_tmp["Size"]=v
    
                    if k=="Speed":
                        mem_tmp["Speed"]=v
    
                    if k=="Locator":
                        mem_key=v
            if mem_key:
                mem[mem_key]=mem_tmp
    
    return mem


def getMemory(p_debug=0):

    mem=getMemoryInfo(p_debug)
    
    total_ram=0    
    for m in mem:
        sz=mem[m]["Size"].split()[0]
        try:
            total_ram+=int(sz)
        except:
            # this catch the case where we have a non integer value : ['Size', ' No Module Installed']
            pass
    
    return total_ram    


def checkMemorySpeed(p_debug=0):
    speed={}
    mem=getMemoryInfo(p_debug)
    
    if not len(mem):
        return True,mem
        
    for m in mem:
        if mem[m].has_key("Speed"):
            if mem[m]["Speed"]=='Unknown':
                continue
            s=mem[m]["Speed"]
            speed[s]=True

    if p_debug:
        print speed

    if len(speed)==0:
        return True,mem

    return (len(speed)==1,mem)


def checkMemorySize(p_debug=0):
    size={}
    mem=getMemoryInfo(p_debug)
    
    if not len(mem):
        return True,mem

    for m in mem:
        if mem[m].has_key("Size"):
            if mem[m]["Size"]=='No Module Installed':
                continue
            s=mem[m]["Size"]
            size[s]=True

    if p_debug:
        print size

    if len(size)==0:
        return True,mem

    return (len(size)==1,mem)


def getBiosInfos(p_debug=0):
    bios={}
    cmd="/usr/sbin/dmidecode"
    if os.geteuid() != 0:
        cmd = 'sudo ' + cmd
    try:
        fd=os.popen(cmd)
        data=fd.read()
    except:
        return mem
            
    try:
        fd.close()
    except:
        pass
        
    dmi_data=data.split("Handle 0x")
    
    
    for handle in dmi_data:
        if handle.find("DMI type 0,")!=-1:
            if p_debug : print >>sys.stderr, "find DMI entry for bios"
            
            for field in handle.replace("\t","").split("\n"):
                k_v=field.split(":")
                if len(k_v)>1:
                    if p_debug : print k_v
                    k,v=(k_v[0].strip(),k_v[1].strip())
    
                    if k=="Vendor":
                        bios["Vendor"]=v.strip()
    
                    if k=="Version":
                        bios["Version"]=v.strip()

                    if k=="Release Date":
                        bios["Release Date"]=v.strip()
    
    return bios

def getSystemInformation(p_debug=0):
    sysinfo={}
    cmd="/usr/sbin/dmidecode"
    if os.geteuid() != 0:
        cmd = 'sudo ' + cmd
    try:
        fd=os.popen(cmd)
        data=fd.read()
    except:
        return mem
            
    try:
        fd.close()
    except:
        pass
        
    dmi_data=data.split("Handle 0x")
    
    for handle in dmi_data:
        if handle.find("DMI type 1,")!=-1:
            if p_debug : print >>sys.stderr, "find DMI entry for System Information"
            
            for field in handle.replace("\t","").split("\n"):
                k_v=field.split(":")
                if len(k_v)>1:
                    if p_debug : print k_v
                    k,v=(k_v[0].strip(),k_v[1].strip())
    
                    if k=="Manufacturer":
                        sysinfo["Manufacturer"]=v.strip()
    
                    if k=="Product Name":
                        sysinfo["Product Name"]=v.strip()

                    if k=="Serial Number":
                        sysinfo["Serial Number"]=v.strip()

    return sysinfo

def getCpuCache(p_debug=0):
    cpuCache={}
    cmd="/usr/sbin/dmidecode"
    if os.geteuid() != 0:
        cmd = 'sudo ' + cmd
    try:
        fd=os.popen(cmd)
        data=fd.read()
    except:
        return mem
            
    try:
        fd.close()
    except:
        pass
    
    dmi_data=data.split("Handle 0x")
    cpu_number=0
    for handle in dmi_data:
        if handle.find("DMI type 7,")!=-1:
            if p_debug : print >>sys.stderr, "find DMI entry for Cache Information"
            tmpCache={}
            l2=False
            for field in handle.replace("\t","").split("\n"):
                k_v=field.split(":")
                if len(k_v)>1:
                    if p_debug : print k_v
                    k,v=(k_v[0].strip(),k_v[1].strip())
    
                    if k=="Configuration":
                        if v.strip().find("Level 2")!=-1:
                            l2=True
                        
                    if k=="Installed Size" and l2:
                        tmpCache["Size"]=v.strip()
            if l2:
                cpuCache["%s" % cpu_number]=tmpCache
                cpu_number+=1
            
    return cpuCache

def getProcessorInformation(p_debug=0):
    cpuinfo={}
    cmd="/usr/sbin/dmidecode"
    if os.geteuid() != 0:
        cmd = 'sudo ' + cmd
    try:
        fd=os.popen(cmd)
        data=fd.read()
    except:
        return mem
            
    try:
        fd.close()
    except:
        pass
    
    cpuCache=getCpuCache(p_debug)
    dmi_data=data.split("Handle 0x")
    cpu_number=0
    for handle in dmi_data:
        if handle.find("DMI type 4,")!=-1:
            if p_debug :
                print >>sys.stderr, "find DMI entry for Processor Information"
            tmpCpu={}
            for field in handle.replace("\t","").split("\n"):
                k_v=field.split(":")
                if len(k_v)>1:
                    if p_debug : print k_v
                    k,v=(k_v[0].strip(),k_v[1].strip())
    
                    if k=="Family":
                        tmpCpu["Family"]=v.strip()
    
                    if k=="Manufacturer":
                        tmpCpu["Manufacturer"]=v.strip()
                        
                    if k=="Current Speed":
                        tmpCpu["Current Speed"]=v.strip()

                    if k=="Status":
                        tmpCpu["Status"]=v.strip()

            if tmpCpu["Status"]!='Unpopulated':
                cpuinfo["%s" % cpu_number]={'Name':'%s %s' % (tmpCpu['Manufacturer'], tmpCpu['Family']),'Speed': tmpCpu['Current Speed'],'Cache':cpuCache["%s" % cpu_number]['Size']}
                cpu_number+=1
            
    return cpuinfo
